CREATE DATABASE IF NOT EXISTS academia;
USE academia;

CREATE TABLE Aluno (
    id_aluno INT AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf CHAR(11) NOT NULL,
    data_cadastro DATE NOT NULL,
    status_acesso VARCHAR(15) NOT NULL DEFAULT 'Liberado',
    CONSTRAINT PK_Aluno PRIMARY KEY (id_aluno),
    CONSTRAINT UN_Aluno_CPF UNIQUE (cpf)
);