USE academia;

CREATE TABLE Treino (
    id_treino INT AUTO_INCREMENT,
    id_aluno INT NOT NULL,
    divisao_treino CHAR(1) NOT NULL,
    detalhe_exercicios TEXT NOT NULL,
    data_validade DATE NOT NULL,
    CONSTRAINT PK_Treino PRIMARY KEY (id_treino),
    CONSTRAINT FK_Treino_Aluno FOREIGN KEY (id_aluno) REFERENCES Aluno(id_aluno)
);