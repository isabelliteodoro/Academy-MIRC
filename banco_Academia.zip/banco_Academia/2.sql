USE academia;

CREATE TABLE Plano (
    id_plano INT AUTO_INCREMENT,
    nome_plano VARCHAR(50) NOT NULL,
    valor_mensal DECIMAL(6,2) NOT NULL,
    duracao_meses INT NOT NULL,
    descricao_beneficios TEXT,
	CONSTRAINT PK_Plano PRIMARY KEY (id_plano),
    CONSTRAINT UN_Plano_Nome UNIQUE (nome_plano)
);