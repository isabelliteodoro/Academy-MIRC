USE academia;

INSERT INTO Aluno (nome, cpf, 
data_cadastro, status_acesso) 
VALUES
('Camila Fogaci', '12345678901', '2026-01-10', 'Liberado'),
('Isabelli Teodoro', '23456789012', '2026-02-15', 'Liberado'),
('Maria Clara Toseti', '34567890123', '2026-03-20', 'Bloqueado'),
('Rafael Garicia', '45678901234', '2026-04-05', 'Liberado'),
('Guilherme Tangerina', '56789012345', '2026-05-12', 'Liberado');

INSERT INTO Plano (nome_plano, valor_mensal, 
duracao_meses, descricao_beneficios) 
VALUES
('Plano Mensal', 119.90, 1, 'Acesso livre à musculação.'),
('Plano Trimestral', 99.90, 3, 'Acesso à musculação e área de cardio.'),
('Plano Semestral', 89.90, 6, 'Acesso livre + 1 avaliação física inclusa.'),
('Plano Anual', 79.90, 12, 'Acesso total, todas as aulas e avaliações inclusas.'),
('Plano VIP', 199.90, 12, 'Acesso total, armário exclusivo e direito a levar um acompanhante.');

INSERT INTO Matricula (id_aluno, id_plano, 
data_inicio, status_pagamento) 
VALUES
(1, 4, '2026-01-10', 'Em dia'),        
(2, 1, '2026-02-15', 'Em dia'),        
(3, 2, '2026-03-20', 'Inadimplente'),   
(4, 5, '2026-04-05', 'Em dia'),       
(5, 3, '2026-05-12', 'Em dia');        

INSERT INTO Treino (id_aluno, divisao_treino, 
detalhe_exercicios, data_validade) 
VALUES
(1, 'A', 'Supino Reto: 4x10, Desenvolvimento: 3x12, Tríceps na Polia: 4x12', '2026-03-10'),
(2, 'B', 'Agachamento Livre: 4x10, Leg Press: 3x12, Cadeira Extensora: 4x15', '2026-04-15'),
(3, 'A', 'Puxada Aberta: 4x10, Remada Baixa: 3x12, Rosca Direta: 4x10', '2026-05-20'),
(4, 'C', 'Elevação Lateral: 4x15, Abdominais: 3x20, Esteira: 20 min', '2026-06-05'),
(5, 'B', 'Stiff: 4x10, Cadeira Flexora: 4x12, Panturrilha em pé: 3x20', '2026-07-12');