USE academia;

CREATE TABLE Matricula (
    id_matricula INT AUTO_INCREMENT,
    id_aluno INT NOT NULL,
    id_plano INT NOT NULL,
    data_inicio DATE NOT NULL,
    status_pagamento VARCHAR(15) NOT NULL DEFAULT 'Em dia',
    CONSTRAINT PK_Matricula PRIMARY KEY (id_matricula),
    CONSTRAINT FK_Matricula_Aluno FOREIGN KEY (id_aluno) REFERENCES Aluno(id_aluno),
    CONSTRAINT FK_Matricula_Plano FOREIGN KEY (id_plano) REFERENCES Plano(id_plano)
);